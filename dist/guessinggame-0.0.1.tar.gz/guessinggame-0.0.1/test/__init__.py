"""Test Package for guessinggame.

Author: Denea Clark deneac15@ksu.edu
Version: 0.1
"""
